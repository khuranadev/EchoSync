import flet as ft
import json

def load_tasks_from_file(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

            try:
                data = json.loads(content)
                return data.get("tasks", [])
            except json.JSONDecodeError:
                pass

            return [line.strip() for line in content.split("\n") if line.strip()]
    except Exception as e:
        print("Error loading file:", e)
        return []

def main(page: ft.Page):
    page.title = "EchoSync Task Manager"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.scroll = ft.ScrollMode.AUTO
    page.padding = 30
    page.vertical_alignment = ft.MainAxisAlignment.START
    page.bgcolor = "#f7f7f7"

    todo_list = ft.Column(spacing=10)
    task_input = ft.TextField(hint_text="Enter a task...", expand=True)

    file_picker = ft.FilePicker()

    def add_task(e=None):
        if task_input.value.strip():
            task = create_task_row(task_input.value.strip())
            todo_list.controls.append(task)
            task_input.value = ""
            page.update()

    def create_task_row(task_text):
        task_display = ft.Text(task_text, expand=True)
        checkbox = ft.Checkbox()
        task_input_field = ft.TextField(value=task_text, expand=True, visible=False)

        def toggle_complete(e):
            if checkbox.value:
                task_display.style = ft.TextStyle(color=ft.colors.GREY, decoration=ft.TextDecoration.LINE_THROUGH)
            else:
                task_display.style = ft.TextStyle(color=ft.colors.BLACK)
            page.update()

        checkbox.on_change = toggle_complete

        def enable_edit(e):
            task_display.visible = False
            task_input_field.visible = True
            edit_btn.visible = False
            save_btn.visible = True
            page.update()

        def save_edit(e):
            updated = task_input_field.value.strip()
            if updated:
                task_display.value = updated
                task_display.visible = True
                task_input_field.visible = False
                edit_btn.visible = True
                save_btn.visible = False
                page.update()

        def remove(e):
            todo_list.controls.remove(task_row)
            page.update()

        edit_btn = ft.IconButton(icon=ft.icons.EDIT, on_click=enable_edit)
        save_btn = ft.IconButton(icon=ft.icons.SAVE, on_click=save_edit, visible=False)
        delete_btn = ft.IconButton(icon=ft.icons.DELETE, on_click=remove)

        task_row = ft.Container(
            content=ft.Row([checkbox, task_display, task_input_field, edit_btn, save_btn, delete_btn]),
            bgcolor=ft.colors.WHITE,
            padding=10,
            border_radius=10,
            shadow=ft.BoxShadow(blur_radius=4, color=ft.colors.BLUE_GREY_100, spread_radius=1)
        )
        return task_row

    def on_file_picked(e: ft.FilePickerResultEvent):
        if e.files:
            file_path = e.files[0].path
            tasks = load_tasks_from_file(file_path)
            todo_list.controls.clear()
            for task_text in tasks:
                todo_list.controls.append(create_task_row(task_text))
            page.update()

    file_picker.on_result = on_file_picked
    load_button = ft.ElevatedButton("Load Task File", on_click=lambda _: file_picker.pick_files())

    page.overlay.append(file_picker)
    page.add(
        ft.Column([
            ft.Text("EchoSync Task Assistant", size=30, weight=ft.FontWeight.BOLD, color=ft.colors.BLUE_900),
            ft.Row([task_input, ft.ElevatedButton("Add Task", on_click=add_task)]),
            load_button,
            ft.Divider(),
            todo_list
        ], spacing=20)
    )

ft.app(target=main)
